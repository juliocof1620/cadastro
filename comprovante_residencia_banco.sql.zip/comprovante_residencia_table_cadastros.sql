
-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastros`
--

DROP TABLE IF EXISTS `cadastros`;
CREATE TABLE `cadastros` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sobrenome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rua` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bairro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `complemento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacoes` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `cadastros`
--

INSERT DELAYED IGNORE INTO `cadastros` (`id`, `nome`, `sobrenome`, `email`, `rua`, `bairro`, `numero`, `complemento`, `cidade`, `uf`, `status`, `observacoes`, `img`, `created_at`, `updated_at`) VALUES
(1, 'julio', 'florido', 'juliocof1980@gmail.com', 'antonio gomes', 'bela vista', 135, 'casa', 'tres corações', 'sp', 'true', 'teste', NULL, NULL, NULL),
(2, 'joao', 'silva', 'joao@hotmail.com', 'naves', 'bela vista', 123, 'casa', 'Osasco', 'SP', 'ativo', 'teste', NULL, '2022-05-13 18:32:48', '2022-05-13 18:32:48'),
(3, 'çlkçok', 'çlkçlk', 'lçkçlk', 'çlk', 'lkçlk', 123, 'çlkçlk', 'çlk', 'çkçlk', 'çlk', 'çlk', NULL, '2022-05-13 19:56:39', '2022-05-13 19:56:39'),
(4, 'dsfsdf', 'sdfsdf', 'dsfsdf', 'sdfsd', 'sdfsdf', 123, 'sdfsdf', 'sdfsdf', 'dsfsdf', 'dsfsdf', 'dsfsdf', NULL, '2022-05-13 20:00:04', '2022-05-13 20:00:04'),
(5, 'van', '231321', '321321', 'kjhkjh', 'lkjlkj', 35454, 'kjhkjh', 'ljkhkjh', 'lkjkjh', 'lkjlj', 'lkj', '268660_259637750729201_100000489346826_1072137_6050762_n[1].jpg', '2022-05-13 20:14:01', '2022-05-13 20:14:01');
